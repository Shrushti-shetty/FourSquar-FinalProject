//
//  uploadImageCollectionViewCell.swift
//  FOURSQUAREAPP
//
//  Created by Shrushti Shetty on 09/01/23.
//

import UIKit

class UploadImageCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var image: UIImageView!
    
}
