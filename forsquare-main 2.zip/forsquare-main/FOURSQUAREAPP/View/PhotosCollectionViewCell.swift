//
//  PhotosCollectionViewCell.swift
//  FOURSQUAREAPP
//
//  Created by Shrushti Shetty on 05/01/23.
//

import UIKit

class PhotosCollectionViewCell: UICollectionViewCell {
    
}
