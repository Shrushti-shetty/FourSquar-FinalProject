//
//  Review.swift
//  FOURSQUAREAPP
//
//  Created by Manish R T on 10/01/23.
//

import Foundation
struct Review {
    var profilePicture: String?
    var userName: String
    var review: String
    var date: String
}
