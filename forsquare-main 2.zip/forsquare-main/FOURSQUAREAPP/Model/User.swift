//
//  User.swift
//  FOURSQUAREAPP
//
//  Created by Shrushti Shetty on 06/01/23.
//

import Foundation
struct User {
    var userName: String
    var email: String
    var password: String
    var phoneNumber: String
}
