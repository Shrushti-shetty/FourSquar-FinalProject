//
//  SearchList.swift
//  FOURSQUAREAPP
//
//  Created by Shrushti Shetty on 07/01/23.
//

import Foundation
struct Place {
    var placeName: String
    var address: String
    var ratings: Double
    var phoneNumber: String
    var distance: Double
    var placeType: String
}


